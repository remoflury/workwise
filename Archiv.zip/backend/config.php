<?php
// //Connection to FHGR
// $host = "localhost";
// $user = "	148904_3_1";
// $password = "6yiLgACwDY74";
// $dbname = "	148904_3_1";

// $pdo = new PDO('mysql:host='. $host . '; dbname=' . $dbname . ';charset=utf8', $user, $password); //set connection to DB
//Connection to Cyon
$host = "149.126.4.110";
$user = "fypozoko_workwis";
$password = "JU%5dy;6xU:3q";
$dbname = "fypozoko_workwise1";

$pdo = new PDO('mysql:host='. $host . '; dbname=' . $dbname . ';charset=utf8', $user, $password); //set connection to DB
