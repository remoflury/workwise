<span class="block bg-white w-full h-1 rounded-full transition duration-500"></span>
<span class="block bg-white w-full h-1 rounded-full transition duration-500"></span>
<span class="block bg-white w-full h-1 rounded-full transition duration-500"></span>