<header>
  <?php include_once 'navigation/navigation.php'; ?>

</header>