<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="src/assets/favicon/Favicon WorkWise_v2.svg">
  
<!-- CSS -->
<link rel="stylesheet" href="css/output.css">

<!-- Fonts -->
<link rel="stylesheet" href="https://use.typekit.net/alh7sdw.css">