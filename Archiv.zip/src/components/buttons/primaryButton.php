<a href="<?php echo $link ?>" class="group" title="<?php echo $btnText ?>">
  <button class="border-2 border-orange-dark bg-orange-dark px-16 py-4 inline-block group-hover:bg-white transition">
    <p class="font-bold text-white group-hover:text-orange-dark transition"><?php echo $btnText ?></p>
  </button>
</a>