
<button onclick="<?php echo $onClickFunction?>" class="group border-2 border-orange-dark bg-orange-dark px-16 py-4 inline-block hover:bg-white transition">
  <p class="font-bold text-white group-hover:text-orange-dark transition"><?php echo $btnText ?></p>
</button>